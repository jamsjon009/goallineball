<?php

    add_action( 'woocommerce_settings_tabs_settings_tab_cart_header_menu', 'qs_settings_tab_cart_header_menu' );
    add_action( 'woocommerce_update_options_settings_tab_qs_header_cart', 'qs_header_cart_update_settings' );

    function qs_settings_tab_cart_header_menu() {
        woocommerce_admin_fields( qs_settings_tab_cart_header_get_settings() );
    }

    function qs_settings_tab_cart_header_get_settings() {

        $settings = array(

            'section_title' => array(
                'name'     => __( 'Cart Menu', 'woocommerce-settings-tab-demo' ),
                'type'     => 'title',
                'desc'     => '',
                'id'       => 'wc_settings_tab_qs_header_cart_section_title'
            ),

            'title' => array(
                'name' => __( 'Title', 'woocommerce-settings-tab-demo' ),
                'type' => 'text',
                'desc' => __( 'This is some helper text', 'woocommerce-settings-tab-demo' ),
                'id'   => 'wc_settings_tab_qs_header_cart_title'
            ),
        
            'section_end' => array(
                'type' => 'sectionend',
                'id' => 'wc_settings_tab_qs_header_cart_section_end'
            )
        );

        return apply_filters( 'wc_settings_tab_qs_header_cart_settings', $settings );
    }

    function qs_header_cart_update_settings() {
        woocommerce_update_options( get_settings() );
    }