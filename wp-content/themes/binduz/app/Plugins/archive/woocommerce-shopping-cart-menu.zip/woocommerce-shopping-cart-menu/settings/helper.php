<?php

// Settings
if( !function_exists('qs_wc_get_registered_nav_menus') ){

	function qs_wc_get_registered_nav_menus(){
		  
		  $registered_arr = [];
		 
		  foreach(get_nav_menu_locations() as $key => $item){
			$registered_arr[$key] = $key;
		  }

		  return $registered_arr;
	}
}