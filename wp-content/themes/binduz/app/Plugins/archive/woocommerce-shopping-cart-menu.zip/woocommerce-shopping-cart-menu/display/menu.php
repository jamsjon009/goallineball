<?php

/**
 * Place a cart icon with the number of items and total cost in the menu bar.
 * Shortcode
 *  header menu
 */
add_filter('wp_nav_menu_items', 'qs_shopping_cart_in_header_wc_menucart', 10, 2);
function qs_shopping_cart_in_header_wc_menucart($menu, $args)
{

	if (!class_exists('woocommerce')) {
		return $menu;
	}

	// Check if WooCommerce is active and add a new item to a menu assigned to Primary Navigation Menu location
	if (get_option('wc_settings_tab_qs_cart_in_header_menu') !== $args->theme_location) {
		return $menu;
	}

	ob_start();

	global $woocommerce;

	$price_seperator     = get_option('wc_settings_tab_qs_cart_in_header_price_seperator_cart', '-');
	$cart_icon_position  = get_option('wc_settings_tab_qs_cart_in_header_cart_icon_position', 'left');
	$show_price          = get_option('wc_settings_tab_qs_cart_in_header_show_price_cart', 'no');
	$viewing_cart        = get_option('wc_settings_tab_qs_cart_in_header_view_shopping_cart', 'View your shopping cart');
	$start_shopping      = get_option('wc_settings_tab_qs_cart_in_header_start_shopping', 'Start shopping');
	$cart_url            = wc_get_cart_url();
	$shop_page_url       = get_permalink(wc_get_page_id('shop'));
	$cart_contents_count = $woocommerce->cart->cart_contents_count;
	$cart_contents       = sprintf(_n('<span class="qs-wc-cart-count"> %d item </span>', '<span class="qs-wc-cart-count"> %d items </span>', $cart_contents_count, 'woocommerce-shopping-cart-menu'), $cart_contents_count);
	$cart_total          = $woocommerce->cart->get_cart_total();

	// Uncomment the line below to hide nav menu cart item when there are no items in the cart
	if ($cart_contents_count > 0 || get_option('wc_settings_tab_qs_cart_in_header_show_empty_cart', 'no') == 'yes') {
		if ($cart_contents_count == 0) {
			$menu_item = '<li class="menu-item menu-item-type-post_type menu-item-object-page nav-item"><a class="qs-menu--cart-contents" href="' . $shop_page_url . '" title="' . $start_shopping . '">';
		} else {
			$menu_item = '<li class="menu-item menu-item-type-post_type menu-item-object-page nav-item"><a class="qs-menu--cart-contents" href="' . $cart_url . '" title="' . $viewing_cart . '">';
		}


		if ($cart_icon_position == 'left') {
			$menu_item .= sprintf('<i class="%s"></i> ', get_option('wc_settings_tab_qs_cart_in_header_icon_class', 'fa fa-shopping-cart'));
			$menu_item .= $cart_contents;
		} else {
			$menu_item .= $cart_contents;
			$menu_item .= sprintf('<i class="%s"></i> ', get_option('wc_settings_tab_qs_cart_in_header_icon_class', 'fa fa-shopping-cart'));
		}

		if ($show_price == 'yes') {
			$menu_item .=  $price_seperator . $cart_total;
		}

		$menu_item .= '</a></li>';
		// Uncomment the line below to hide nav menu cart item when there are no items in the cart
	}
	echo isset($menu_item) ? $menu_item : '';
	$social = ob_get_clean();
	return $menu . $social;
}

add_filter('woocommerce_add_to_cart_fragments', 'qs_header_cart__wc_refresh_mini_cart_count');
function qs_header_cart__wc_refresh_mini_cart_count($fragments)
{
	ob_start();

	global $woocommerce;


	$price_seperator    = get_option('wc_settings_tab_qs_cart_in_header_price_seperator_cart', '-');
	$show_price         = get_option('wc_settings_tab_qs_cart_in_header_show_price_cart', 'no');
	$cart_icon_position = get_option('wc_settings_tab_qs_cart_in_header_cart_icon_position', 'left');
	$viewing_cart       = get_option('wc_settings_tab_qs_cart_in_header_view_shopping_cart', 'View your shopping cart');
	$start_shopping     = get_option('wc_settings_tab_qs_cart_in_header_start_shopping', 'Start shopping');
	$cart_url           = wc_get_cart_url();
	$shop_page_url      = get_permalink(wc_get_page_id('shop'));
	$cart_contents_count = $woocommerce->cart->cart_contents_count;

	$item = get_option('wc_settings_tab_qs_cart_in_header_cart_item', '');
	$items = get_option('wc_settings_tab_qs_cart_in_header_cart_items', '');

	$cart_contents = sprintf(_n("<span class='qs-wc-cart-count'> %d $items </span>", "<span class='qs-wc-cart-count'> %d $item </span>", $cart_contents_count, 'woocommerce-shopping-cart-menu'), $cart_contents_count);
	$cart_total = $woocommerce->cart->get_cart_total();

	if ($cart_contents_count > 0 || get_option('wc_settings_tab_qs_cart_in_header_show_empty_cart', 'no') == 'yes') {

		if ($cart_contents_count == 0) {
			$menu_item = '<a class="qs-menu--cart-contents" href="' . $shop_page_url . '" title="' . $start_shopping . '">';
		} else {
			$menu_item = '<a class="qs-menu--cart-contents" href="' . $cart_url . '" title="' . $viewing_cart . '">';
		}

		if ($cart_icon_position == 'left') {
			$menu_item .= sprintf('<i class="%s"></i> ', get_option('wc_settings_tab_qs_cart_in_header_icon_class', 'fa fa-shopping-cart'));
			$menu_item .= $cart_contents;
		} else {
			$menu_item .= $cart_contents;
			$menu_item .= sprintf('<i class="%s"></i> ', get_option('wc_settings_tab_qs_cart_in_header_icon_class', 'fa fa-shopping-cart'));
		}

		if ($show_price == 'yes') {
			$menu_item .=  $price_seperator . $cart_total;
		}

		$menu_item .= '</a>';
		// Uncomment the line below to hide nav menu cart item when there are no items in the cart
	}

	$menu_item = null; // or initialize with some default value
	echo $menu_item;
?>
  
    <?php
	$fragments['.qs-menu--cart-contents'] = ob_get_clean();
	return $fragments;
}


add_action('qs_wc_custom_cart_content_area', '_qs_wc_custom_cart_content_area');
add_shortcode('qs_wc_custom_cart_content_area', '_qs_wc_custom_cart_content_area');

function _qs_wc_custom_cart_content_area()
{

	if (!class_exists('woocommerce')) {
		return;
	}

	global $woocommerce;

	$custom_area     = get_option('wc_settings_tab_qs_cart_custom_area', 'no');

	if ($custom_area != 'yes') {
		return;
	}

	$price_seperator     = get_option('wc_settings_tab_qs_cart_in_header_price_seperator_cart', '-');
	$cart_icon_position  = get_option('wc_settings_tab_qs_cart_in_header_cart_icon_position', 'left');
	$show_price          = get_option('wc_settings_tab_qs_cart_in_header_show_price_cart', 'no');
	$viewing_cart        = get_option('wc_settings_tab_qs_cart_in_header_view_shopping_cart', 'View your shopping cart');
	$start_shopping      = get_option('wc_settings_tab_qs_cart_in_header_start_shopping', 'Start shopping');
	$cart_url            = wc_get_cart_url();
	$shop_page_url       = get_permalink(wc_get_page_id('shop'));
	$cart_contents_count = $woocommerce->cart->cart_contents_count;
	$cart_contents       = sprintf(_n('<span class="qs-wc-cart-count"> %d item </span>', '<span class="qs-wc-cart-count"> %d items </span>', $cart_contents_count, 'woocommerce-shopping-cart-menu'), $cart_contents_count);
	$cart_total          = $woocommerce->cart->get_cart_total();
	ob_start();
	// Uncomment the line below to hide nav menu cart item when there are no items in the cart
	if ($cart_contents_count > 0 || get_option('wc_settings_tab_qs_cart_in_header_show_empty_cart', 'no') == 'yes') {
		if ($cart_contents_count == 0) {
			$menu_item = '<div class="qs-custom-wc-cart-area"><a class="qs-menu--cart-contents" href="' . $shop_page_url . '" title="' . $start_shopping . '">';
		} else {
			$menu_item = '<div class="qs-custom-wc-cart-area"><a class="qs-menu--cart-contents" href="' . $cart_url . '" title="' . $viewing_cart . '">';
		}


		if ($cart_icon_position == 'left') {
			$menu_item .= sprintf('<i class="%s"></i> ', get_option('wc_settings_tab_qs_cart_in_header_icon_class', 'fa fa-shopping-cart'));
			$menu_item .= $cart_contents;
		} else {
			$menu_item .= $cart_contents;
			$menu_item .= sprintf('<i class="%s"></i> ', get_option('wc_settings_tab_qs_cart_in_header_icon_class', 'fa fa-shopping-cart'));
		}

		if ($show_price == 'yes') {
			$menu_item .=  $price_seperator . $cart_total;
		}

		$menu_item .= '</a></div>';
		// Uncomment the line below to hide nav menu cart item when there are no items in the cart
	}

	echo $menu_item;

	$output_string = ob_get_contents();
	ob_end_clean();
	return $output_string;
}
