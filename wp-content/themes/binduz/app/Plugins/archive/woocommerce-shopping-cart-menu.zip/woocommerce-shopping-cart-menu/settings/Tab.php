<?php

class WC_Settings_Tab_Shopping_Cart_In_Header{


    public static function init() {
        add_filter( 'woocommerce_settings_tabs_array', __CLASS__ . '::add_settings_tab', 50 );
        add_action( 'woocommerce_settings_tabs_qs_wc_quick_cart_settings_tab', __CLASS__ . '::settings_tab' );
        add_action( 'woocommerce_update_options_qs_wc_quick_cart_settings_tab', __CLASS__ . '::update_settings' );
        add_filter( 'woocommerce_get_sections_qs_wc_quick_cart_settings_tab', __CLASS__. '::whitelabel_add_section' );
        //add_filter( 'woocommerce_sections_qs_wc_quick_cart_settings_tab', __CLASS__. '::whitelabel_add_section' );
    }

    public static function whitelabel_add_section($sections){
        
     
        $sections['qs-cart-white-label'] = __( 'White Label', 'woocommerce-shopping-cart-menu' );
        return $sections;
    }


    public static function add_settings_tab( $settings_tabs ) {
      
        $settings_tabs['qs_wc_quick_cart_settings_tab'] = __( 'QS Quick Cart', 'woocommerce-shopping-cart-menu' );
        return $settings_tabs;
    }


    /*
    * Uses the WooCommerce admin fields API to output settings via the @see woocommerce_admin_fields() function.
    *
    * @uses woocommerce_admin_fields()
    * @uses self::get_settings()
    */
    public static function settings_tab() {
        woocommerce_admin_fields( self::get_settings() );
    }


    /** 
     * Uses the WooCommerce options API to save settings via the @see woocommerce_update_options() function.
     *
     * @uses woocommerce_update_options()
     * @uses self::get_settings()
     */
    public static function update_settings() {
        woocommerce_update_options( self::get_settings() );
    }


    /*
    * Get all the settings for this plugin for @see woocommerce_admin_fields() function.
    *
    * @return array Array of settings for @see woocommerce_admin_fields() function.
    */
    public static function get_settings() {

        $settings = array(

            'section_title' => array(
                'name'     => __( 'Cart In Header', 'woocommerce-shopping-cart-menu' ),
                'type'     => 'title',
                'desc'     => '',
                'id'       => 'wc_settings_tab_s_cart_in_header_section_title'
            ),

            'view_your_shopping_cart' => array(
                'name' => __( 'View your shopping cart', 'woocommerce-shopping-cart-menu' ),
                'type' => 'text',
                'desc' => __( 'View your shopping cart Lavel', 'woocommerce-shopping-cart-menu' ),
                'id'   => 'wc_settings_tab_qs_cart_in_header_view_shopping_cart'
            ), 
            
            'start_shopping' => array(
                'name' => __( 'Start Shopping', 'woocommerce-shopping-cart-menu' ),
                'type' => 'text',
                'desc' => __( 'Start shopping Label', 'woocommerce-shopping-cart-menu' ),
                'id'   => 'wc_settings_tab_qs_cart_in_header_start_shopping'
            ),

            'cart_item_label' => array(
                'name' => __( 'Item', 'woocommerce-shopping-cart-menu' ),
                'type' => 'text',
                'desc' => __( 'Cart Item Label', 'woocommerce-shopping-cart-menu' ),
                'id'   => 'wc_settings_tab_qs_cart_in_header_cart_item'
            ),

            'cart_items_label' => array(
                'name' => __( 'Items', 'woocommerce-shopping-cart-menu' ),
                'type' => 'text',
                'desc' => __( 'Cart Items Label', 'woocommerce-shopping-cart-menu' ),
                'id'   => 'wc_settings_tab_qs_cart_in_header_cart_items'
            ),
            
            'icon_class' => array(
                'name' => __( 'Icon Class', 'woocommerce-shopping-cart-menu' ),
                'type' => 'text',
                'desc' => __( 'This is fontaweome cart icon class', 'woocommerce-shopping-cart-menu' ),
                'id'   => 'wc_settings_tab_qs_cart_in_header_icon_class'
            ),

            'header_cart_icon_position' => array(
                'title' => 'Cart Icon Position',
                'description' => 'Show Cart icon Position',
                'type' => 'select',
                'default' => 'left',
                'id'   => 'wc_settings_tab_qs_cart_in_header_cart_icon_position',
                'options' => [
                    'left' => esc_html__('Left','woocommerce-shopping-cart-menu'),
                    'right' => esc_html__('Right','woocommerce-shopping-cart-menu')
                ]
            ),

            'header_menu_id' => array(
                'title' => 'Menu',
                'description' => 'Select header menu to display cart count icon',
                'type' => 'select',
                'default' => 'primary',
                'id'   => 'wc_settings_tab_qs_cart_in_header_menu',
                'options' => qs_wc_get_registered_nav_menus()
            ),

            'header_cart_show_price' => array(
                'title' => 'Show Price',
                'description' => 'Show Price header menu to display cart count icon',
                'type' => 'select',
                'default' => 'no',
                'id'   => 'wc_settings_tab_qs_cart_in_header_show_price_cart',
                'options' => [
                    'yes' => esc_html__('Yes','woocommerce-shopping-cart-menu'),
                    'no' => esc_html__('No','woocommerce-shopping-cart-menu')
                ]
            ),

            'header_cart_price_seperator' => array(
                'title' => 'Price Seperator',
                'description' => 'Price Sepearator',
                'type' => 'text',
                'default' => '-',
                'id'   => 'wc_settings_tab_qs_cart_in_header_price_seperator_cart',
                
            ),

            'header_empty_cart_show' => array(
                'title' => 'Show Empty Cart',
                'description' => 'Select header menu to display cart count icon',
                'type' => 'select',
                'default' => 'no',
                'id'   => 'wc_settings_tab_qs_cart_in_header_show_empty_cart',
                'options' => [
                    'yes' => esc_html__('Yes','woocommerce-shopping-cart-menu'),
                    'no' => esc_html__('No','woocommerce-shopping-cart-menu')
                ]
            ),
            
            'qs_cart_custom_area' => array(
                'title' => 'Custom theme Area',
                'description' => 'Select Theme custom area to display cart count icon',
                'type' => 'select',
                'default' => 'no',
                'id'   => 'wc_settings_tab_qs_cart_custom_area',
                'options' => [
                    'yes' => esc_html__('Yes','woocommerce-shopping-cart-menu'),
                    'no' => esc_html__('No','woocommerce-shopping-cart-menu')
                ]
            ),

            'custom_cart_showrt_pager' => array(
                'title' => 'Shortcode',
                'description' => 'use at any Page Builder',
                'type' => 'text',
                'readonly' => true,
                'default' => '[qs_wc_custom_cart_content_area]',
                'id'   => 'wc_settings_tab_qs_cart_in_short_code_page_bulider',
               
            ),
        
            'section_end' => array(
                'type' => 'sectionend',
                'id' => 'wc_settings_tab_cart_qs_in_header_section_end'
            )
        );

        return apply_filters( 'wc_settings_tab_qs_cart_in_header_settings', $settings );
    }

}

WC_Settings_Tab_Shopping_Cart_In_Header::init();