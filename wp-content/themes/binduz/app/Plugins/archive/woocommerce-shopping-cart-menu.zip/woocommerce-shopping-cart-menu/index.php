<?php
/**
 * Plugin Name: Quick Shopping Cart for WooCommerce
 * Description: This WooCommerce Shopping Cart plugin to display cart count in header
 * Plugin URI: http://quomodosoft.com/plugins/element-ready-addon-elementor
 * Author: QuomodoSoft
 * Author URI: http://quomodosoft.com
 * Version: 1.1
 * License: GPL2
 * Text Domain: woocommerce-shopping-cart-menu
 * Domain Path: /languages/
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}



/**
* PUGINS MAIN PATH CONSTANT
*/
define( 'QUOMODO_WC_CART_MENU_GEN_VERSIONS', '1.1.0' );
define( 'QUOMODO_WC_CART_MENU_GEN', TRUE );
define( 'QUOMODO_WC_CART_MENU_GEN_ROOT', dirname(__FILE__) );

define( 'QUOMODO_WC_CART_MENU_GEN_URL', plugins_url( '/', __FILE__ ) );
define( 'QUOMODO_WC_CART_MENU_GEN_ROOT_JS', plugins_url( '/assets/js/', __FILE__ ) );
define( 'QUOMODO_WC_CART_MENU_GEN_ROOT_CSS', plugins_url( '/assets/css/', __FILE__ ) );
define( 'QUOMODO_WC_CART_MENU_GEN_ROOT_ICON', plugins_url( '/assets/icons/', __FILE__ ) );
define( 'QUOMODO_WC_CART_MENU_GEN_ROOT_IMG', plugins_url( '/assets/img/', __FILE__ ) );

define( 'QUOMODO_WC_CART_MENU_GEN_DIR_URL', plugin_dir_url( __FILE__ ));
define( 'QUOMODO_WC_CART_MENU_GEN_DIR_PATH', plugin_dir_path( __FILE__ ) );
define( 'QUOMODO_WC_CART_MENU_GEN_BASE', plugin_basename( QUOMODO_WC_CART_MENU_GEN_ROOT ) );

add_action('woocommerce_loaded', 'qs_shopping_cart_widget_init',500);
function qs_shopping_cart_widget_init(){
 
	require_once( QUOMODO_WC_CART_MENU_GEN_DIR_PATH . '/settings/helper.php' );
	require_once( QUOMODO_WC_CART_MENU_GEN_DIR_PATH . '/settings/Tab.php' );
	
	require_once( QUOMODO_WC_CART_MENU_GEN_DIR_PATH . '/display/menu.php' );

	
	
} 
