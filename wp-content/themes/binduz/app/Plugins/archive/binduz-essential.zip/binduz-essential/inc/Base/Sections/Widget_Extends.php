<?php 
namespace Binduz_Essential\Base\Sections;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Element_Base;


class Widget_Extends {
 
    public function register(){
    //    add_action('binduz__widget__extra__option',[$this,'extra_readmore'],9,2);
    //    add_action('binduz_general_grid_top_post_tab',[$this,'extra_readmore'],9,2);
       // do_action('binduz__widget__extra__option',$ele,$widget);
    }

    public function extra_readmore($ele,$widget){

      
 
    }

}