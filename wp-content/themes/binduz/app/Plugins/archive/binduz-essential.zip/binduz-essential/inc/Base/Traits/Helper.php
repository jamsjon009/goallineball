<?php
namespace Binduz_Essential\Base\Traits;

trait Helper {
    
    static public $data = null;
 
    
}